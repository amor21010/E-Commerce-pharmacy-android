package com.aboesmail.omar.pharma;

import android.provider.BaseColumns;

public class ProductContract {
    public static final class ProductEntry implements BaseColumns{
        public static final String TABLE_NAME = "Products";
        public static final String COLUMN_PRODUCT_NAME ="productName";
        public static final String COLUMN_PRICE="price";
        public static final String COLUME_TIMESTAMEP= "timestamp";



    }
}
