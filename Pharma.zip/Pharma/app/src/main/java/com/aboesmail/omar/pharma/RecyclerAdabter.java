package com.aboesmail.omar.pharma;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;

import static java.util.Objects.*;

public class RecyclerAdabter extends RecyclerView.Adapter<RecyclerAdabter.ProductViewHolder> {
    Context context;
    Cursor cursor;
    private List <ProductList> productList=new ArrayList<>();

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {


        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item,viewGroup, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder productViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
    public final static class ProductViewHolder extends RecyclerView.ViewHolder {
        private ImageView DrugPhoto;
        private TextView DrugName;
        private TextView DrugPrice;

        private Button addToCart;
        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            DrugPhoto=itemView.findViewById(R.id.drugphoto);
            DrugName=itemView.findViewById(R.id.drugname);
            DrugPrice=itemView.findViewById(R.id.drugprice);
            addToCart=itemView.findViewById(R.id.addToCart);
        }
    }

}
