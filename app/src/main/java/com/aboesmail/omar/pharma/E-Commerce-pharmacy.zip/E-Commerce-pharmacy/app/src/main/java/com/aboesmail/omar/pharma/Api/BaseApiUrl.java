package com.aboesmail.omar.pharma.Api;

public class BaseApiUrl {
    static final String BaseUrl = "http://testandroidomar.ddns.net:8088/";


    // private static String BaseUrl="http://192.168.1.5:8088/";
    public   String   getBaseUrl() {
        return BaseUrl;
    }

}
